---
title: Everyday Series
subtitle: everyday series subtitle.
description: everyday series description.
featured_image: /images/demo/demo-landscape.jpg
layout: painting-collection
---
everyday series content here
